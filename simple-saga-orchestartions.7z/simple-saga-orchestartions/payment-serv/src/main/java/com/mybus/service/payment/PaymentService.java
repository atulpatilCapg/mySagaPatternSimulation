package com.mybus.service.payment;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class PaymentService {
	private Map<String,BigDecimal> userAccData = new HashMap<>();
	private Map<String,BigDecimal> productPriceData = new HashMap<>();
	@PostConstruct
	public void initData() {
		//user account balance data init
		userAccData.put("ramaLala", new BigDecimal(10000));
		userAccData.put("TomJohnson", new BigDecimal(20000));
		userAccData.put("NitinKumar", new BigDecimal(30000));
		productPriceData.put("ToothPaste", new BigDecimal(50.50));
		productPriceData.put("SandleSoap", new BigDecimal(30.50));
		productPriceData.put("TalcumPowder", new BigDecimal(20.50));
	}
	
	public PaymentResponseDTO processPayment(String correlationId, PaymentRequestDTO payment) {
		//throw new RuntimeException("TestRollback");//Test the rollback functionality 
		log.info("in process parment ws: for event:"+correlationId);
		
		// calculation
		BigDecimal totalPrice = getProductUnitPrice(payment.getProductName())
				.multiply(new BigDecimal(payment.getQuantity()));
		BigDecimal accBal = getAccountBalance(payment.getUserId());
		if (accBal.compareTo(totalPrice) < 0) {
			throw new RuntimeException("Insufficient account balance:");
		} else {
			BigDecimal remainingBalance = accBal.subtract(totalPrice);
			userAccData.put(payment.getUserId(), remainingBalance);
			PaymentResponseDTO resp = new PaymentResponseDTO(payment.getUserId(), payment.getProductName(),
					payment.getQuantity());
			resp.setAmountDeducted(totalPrice);
			resp.setAccountBalance(remainingBalance);
			return resp;
		}
		
	}

	private BigDecimal getAccountBalance(String userId) {	
		//from DB
		return userAccData.get(userId);
	}

	private BigDecimal getProductUnitPrice(String productName) {
		// to do load from DB or from Prop file or from prop file
		return productPriceData.get(productName);
	}

	public Boolean processPaymentRollback(String correlationId, PaymentRequestDTO pymt) {
		log.info("in process parment rollback ws: for event:"+correlationId);
		BigDecimal totalOrderedPrice = getProductUnitPrice(pymt.getProductName())
				.multiply(new BigDecimal(pymt.getQuantity()));
		BigDecimal accCurrentBal = getAccountBalance(pymt.getUserId()).add(totalOrderedPrice);
		userAccData.put(pymt.getUserId(), accCurrentBal);
		return true;
	}
	
	public Map getUserAccoutsData() {
		return userAccData;
	}

}
