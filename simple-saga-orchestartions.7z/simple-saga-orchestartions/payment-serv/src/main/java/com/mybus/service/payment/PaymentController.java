package com.mybus.service.payment;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mybus.event.idompotent.ApiIdempotent;

@RestController
@RequestMapping("payment")
public class PaymentController {
	@Autowired
	private PaymentService service;
	
	@ApiIdempotent
	@PostMapping("/process")
	public PaymentResponseDTO processPayment(
			@RequestHeader("Idempotency-Key") String idempotencyKey,
			@RequestHeader("CorrelationID") String correlationId, @RequestBody PaymentRequestDTO payment) {
		return this.service.processPayment(correlationId, payment);
	}

	@ApiIdempotent
	@PostMapping("/process-rollback")
	public Boolean processPaymentRollback(@RequestHeader("CorrelationID") String correlationId,@RequestBody PaymentRequestDTO payment) {
		return this.service.processPaymentRollback(correlationId, payment);
	}

	@GetMapping("/all-balance")
	 public Map getUserAccoutsData() {return service.getUserAccoutsData();}
}
