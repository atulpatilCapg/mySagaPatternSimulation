package com.mybus.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mybus.dto.QueueData;
import com.mybus.dto.TopicData;

@RestController
@RequestMapping("admin")
public class EventbusAdminController {
	
	@Autowired
	private EventbusService service;

	@PostMapping("/registerQueue")
	public String registerQueue(@RequestBody QueueData queueData) {
		service.registerQueue(queueData);
		return "done";
	}
	@PostMapping("/registerTopic")
	public String registerTopic(@RequestBody TopicData topicData) {
		return "done";
	}
	
    @GetMapping("/alldata")
    public String showAllDataOnQueues(){
    	return service.showAllDataOnQueues();
    }

}
