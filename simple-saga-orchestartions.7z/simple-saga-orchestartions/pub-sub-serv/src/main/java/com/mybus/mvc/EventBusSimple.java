package com.mybus.mvc;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.mybus.dto.QueueData;
import com.mybus.dto.Subscription;
import com.mybus.event.EventBus;
import com.mybus.event.EventMessage;

import jdk.internal.org.jline.utils.Log;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class EventBusSimple implements EventBus {
	// bus holds multiple queues
	private Map<String, Queue<EventMessage>> queueAllData = new ConcurrentHashMap<>();
	private Map<String, Subscription> subscriptionMap = new ConcurrentHashMap<>();
	
	@Override
	public Subscription getSubscriptionOfQ(String queueUrl) {
		return subscriptionMap.get(queueUrl);
	}

	@Override
	public void registerQueue(QueueData queueData) {
		// create queue obj & register it

		if (!queueAllData.containsKey(queueData.getQueueUrl())) {
			Queue<EventMessage> queue = new ConcurrentLinkedQueue<>();
			queueAllData.put(queueData.getQueueUrl(), queue);
			subscriptionMap.put(queueData.getQueueUrl(), queueData.getSubscription());

			System.out.println("Queue created : " + queueData.getQueueUrl());
		} else {
			throw new RuntimeException("Queue already registered:" + queueData.getQueueUrl());
		}

	}

	@Override
	public void push(Subscription subscription, EventMessage msg,String queueName) {
		log.info("****pushing:"+msg.getCorrelationID()+" on Q:"+queueName);
		//can push to multiple queue based on Subscription details
		Queue<EventMessage> q = queueAllData.get(queueName);
		if (q != null) {
			q.add(msg);
		}

	}

	@Override
	public EventMessage pull(String queueUrl, String correlationId) {
		log.info("****Polling:{} on Q:",correlationId,queueUrl);
		Queue<EventMessage> q = queueAllData.get(queueUrl);
		if (q != null && !q.isEmpty()) {
			Optional<EventMessage> result = Optional.empty();
			if(correlationId==null) {
				result = q.stream().findFirst();
			}else {	
				result = q.stream().filter(e-> e.getCorrelationID().equals(correlationId)).findFirst();
			}
			if (result.isEmpty()) {
				return null;
			}
			EventMessage msg = result.get();
			// set bus prop on msg
			return msg;
		}
		return null;
	}

	@Override
	public void delete(String queueUrl, String msgId) {
		log.info("****Deleting:{} on Q:",msgId,queueUrl);
		Queue<EventMessage> q = queueAllData.get(queueUrl);
		if (q != null) {
			for (Iterator itr = q.iterator(); itr.hasNext();) {
				EventMessage eventMessage = (EventMessage) itr.next();
				if (eventMessage.getMessageID().equals(msgId))
					itr.remove();
				break;
			}
		}

	}
	
	@Override
	public String getAllEventsData() {
		
		String result = "";
		queueAllData.keySet().stream().forEach(k->{
			queueAllData.get(k).forEach((e)->{ 
				result.concat(k+" on queue: "+e.getCorrelationID()+"_"+e.getEventName());
				//System.out.println(k+" on queue: "+e.getCorrelationID()+"_"+e.getEventName());
			});
			
		});
		System.out.println("in getAllEventsData@@@@@:"+result);
		return result;
	}
	

}
