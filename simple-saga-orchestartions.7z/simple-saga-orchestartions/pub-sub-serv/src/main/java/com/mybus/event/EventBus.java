package com.mybus.event;

import com.mybus.dto.QueueData;
import com.mybus.dto.Subscription;

public interface EventBus {

	public void registerQueue(QueueData queueData) ;
	public void push(Subscription subscription, EventMessage msg, String queueName);
	public EventMessage pull(String queueUrl,String correlationId); 
	public void delete(String queueUrl, String receiptId) ;
	public Subscription getSubscriptionOfQ(String queueUrl);
	public String getAllEventsData();
}
