package com.mybus.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mybus.event.EventMessage;

@RestController
@RequestMapping("serv")
public class EventbusController {

	@Autowired
	private EventbusService service;

	@PostMapping("/send-to-queue/{queueName}")
	public String sendToQueue(@PathVariable String queueName, @RequestBody EventMessage msg) {
		service.sendToQueue(queueName, msg);
		return "done";
	}

	@GetMapping("/poll-from-queue/{qname}")
	public EventMessage pollFromQueue(@PathVariable(value = "qname") String name,
			@RequestParam(value = "correlationId", required = false) String correlationId) {
		return service.pollFromQueue(name, correlationId);
	}

	@DeleteMapping("/delete-msg/{qName}/{msgId}")
	public boolean deleteMsgOnQ(@PathVariable(value = "qName") String qName,
			@PathVariable(value = "msgId") String msgId) {
		return service.deleteFromQ(qName, msgId);
	}

}
