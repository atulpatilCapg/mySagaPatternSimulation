package com.mybus.mvc;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.mybus.dto.QueueData;
import com.mybus.dto.Subscription;
import com.mybus.event.EventBus;
import com.mybus.event.EventMessage;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class EventbusService {
	private EventBus simpleEventBus;
	
	@PostConstruct
	public void init() {
		simpleEventBus = new EventBusSimple(); 
	}
	
	public void registerQueue(QueueData queueData) {
		simpleEventBus.registerQueue(queueData);
		
	}

	
	public void sendToQueue(String queueName, EventMessage message) {
	
		Subscription subscription =  simpleEventBus.getSubscriptionOfQ(queueName);
		if(subscription==null)
			throw new RuntimeException("Queue is not registered, subscription is null for:"+queueName);
		simpleEventBus.push(subscription, message, queueName);//sending on target queue
	}
	
	public EventMessage pollFromQueue(String sourceQ,String correlationId) {
		//log.info("EventBus module,   eventId:"+correlationId);
		Subscription subscription =  simpleEventBus.getSubscriptionOfQ(sourceQ);
		if(subscription==null)
			return null;//subscription is null means queue not created 
		
		return  simpleEventBus.pull(sourceQ	,correlationId);
	}
	
	public boolean deleteFromQ(String sourceQ , String msgId) {
		try {
			simpleEventBus.delete(sourceQ, msgId);
			return true;
		} catch (Exception e) {
			log.error("deleteFromQ:"+e.getMessage());
			return false;
		}
		
	}

	public String showAllDataOnQueues() {
		return simpleEventBus.getAllEventsData();
		
	}
 
}
