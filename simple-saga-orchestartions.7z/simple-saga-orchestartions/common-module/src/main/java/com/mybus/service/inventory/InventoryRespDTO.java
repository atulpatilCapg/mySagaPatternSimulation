package com.mybus.service.inventory;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InventoryRespDTO {
	private String productName;
	private int remainingQuantity;
}
