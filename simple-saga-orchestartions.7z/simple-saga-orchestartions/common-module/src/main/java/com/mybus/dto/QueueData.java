package com.mybus.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class QueueData implements Serializable {

	private static final long serialVersionUID = 5105021561101886735L;
	private String queueName, queueUrl;
	private boolean isFifo;
	private Subscription subscription;
}
