package com.mybus.service.order;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PurchaseOrder implements Serializable{
	private String orderId, productName,userId;
	private int orderedQuantity;
	private BigDecimal amountPaid;
}
