package com.mybus.service.payment;


import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
public class PaymentResponseDTO {
	private final String userId, productName;
	private final int quantity;
	
	private BigDecimal amountDeducted,accountBalance;

}
