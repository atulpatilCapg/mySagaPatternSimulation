package com.mybus.exception;

public class OperationInProgressException extends Exception {

	public OperationInProgressException(String msg) {
		super(msg);
	}

}
