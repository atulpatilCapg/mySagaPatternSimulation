package com.mybus.event;

import java.io.Serializable;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
public class EventMessage implements Serializable {
//immutable 
	private String eventName,messageID, messageGroupId, sequenceNum, targetQueue, replyToQueue, userId, applId, appName;
	private final String messageFormat = "json";
	private Long timeStamp;
	private String jsonEventData;
	@Setter
	private String correlationID;
	@Setter
	private String idempotencyKey;
}
