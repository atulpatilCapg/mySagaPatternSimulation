package com.mybus.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class TopicData implements Serializable {
	private String topicName, topicUrl;
	private Subscription subscription;
}
