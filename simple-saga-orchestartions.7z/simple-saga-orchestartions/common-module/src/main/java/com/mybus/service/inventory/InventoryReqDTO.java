package com.mybus.service.inventory;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InventoryReqDTO implements Serializable{
	private String userId, productName;
	private int quantity;
}
