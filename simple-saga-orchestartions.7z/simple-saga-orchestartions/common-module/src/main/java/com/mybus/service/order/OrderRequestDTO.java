package com.mybus.service.order;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data
public class OrderRequestDTO implements Serializable {
	private String orderId, productName,userId;
	private int quantity;
}
