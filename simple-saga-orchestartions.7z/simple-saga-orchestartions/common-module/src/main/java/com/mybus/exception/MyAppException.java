package com.mybus.exception;

public class MyAppException extends Exception{
	private boolean suppressStacktrace = true;
	
	public MyAppException(String message) {
		super(message,null,true,false);
	}
	
	 @Override
	    public String toString() {
            return getLocalizedMessage();
	    }

}
