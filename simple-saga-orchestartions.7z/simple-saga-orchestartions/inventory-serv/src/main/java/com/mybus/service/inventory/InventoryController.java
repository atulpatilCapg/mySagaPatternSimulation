package com.mybus.service.inventory;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mybus.event.idompotent.ApiIdempotent;


@RestController
@RequestMapping("inventory")
public class InventoryController {
	@Autowired
	private InventoryService service;

	@ApiIdempotent
	@PostMapping("/process")
	public InventoryRespDTO processInventory(
			@RequestHeader("Idempotency-Key") String idempotencyKey, 
			@RequestHeader("CorrelationID") String correlationId,
			@RequestBody InventoryReqDTO order) {
		// throw error to Test Rollback -----------------------
		// throw new RuntimeException("Temp test Error");
		// ---------------------------------------------
		return this.service.processInventory(correlationId, order);
	}

	@ApiIdempotent
	@PostMapping("/process-rollback")
	public Boolean processInventoryRollback(
			@RequestHeader("Idempotency-Key") String idempotencyKey,
			@RequestHeader("CorrelationID") String correlationId,
			@RequestBody InventoryReqDTO order) {
		return this.service.processInventoryRollback(correlationId, order);
	}

	@GetMapping("/all-ainventory")
	public Map getAllInventoryData() {
		return service.getAllInventoryData();
	}
}