package com.mybus.service.inventory;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class InventoryService {
	private Map<String,Integer> productInventoryData = new HashMap<>();
	
	@PostConstruct
	public void initData() {
		//product inventory data init
		productInventoryData.put("ToothPaste", 1000);
		productInventoryData.put("SandleSoap", 5000);
		productInventoryData.put("TalcumPowder", 500);

	}

	public InventoryRespDTO processInventory(String correlationId, InventoryReqDTO order) {
		//throw new RuntimeException("TestRollback");//Test the rollback functionality 
		log.info("in processInventory WS: for event:"+correlationId);
		int rq = getAvaliableQuantity(order.getProductName());
		if (rq < order.getQuantity())
			throw new RuntimeException("insufficient inventory qualtity for procuct:" + order.getProductName());

		int remainingQty = rq - order.getQuantity();
		// save as avaliable qty in DB
		productInventoryData.put(order.getProductName(), remainingQty);
		
		InventoryRespDTO resp = new InventoryRespDTO(order.getProductName(),remainingQty);

		return resp;
		
	}

	public Boolean processInventoryRollback(String correlationId, InventoryReqDTO order) {
		log.info("in processInventoryRollback: for event:"+correlationId);
		int currentQty = getAvaliableQuantity(order.getProductName())+order.getQuantity();//rollback logic	
		productInventoryData.put(order.getProductName(), currentQty);
		return true;
	}

	public Map getAllInventoryData() {
		return productInventoryData;
	}
	private int getAvaliableQuantity(String productName) {
		// get from DB 
		return productInventoryData.get(productName);
	}

}
