package com.mybus.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
@Configuration
@SpringBootApplication
public class MyInvenetoryApplication {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(MyInvenetoryApplication.class, args);
    }
    
    @Bean
   	public RestTemplate restTemplate(RestTemplateBuilder builder) {
   		return builder.build();
   	}
       
        
}
