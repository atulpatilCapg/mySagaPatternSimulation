package com.mybus.service.order.test;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.mybus.dto.QueueData;
import com.mybus.dto.Subscription;
import com.mybus.service.order.OrderRequestDTO;
import com.mybus.service.order.PurchaseOrder;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
public class TestController {
	
	@PostConstruct
	public void init() {
		testPubSub();//registration of Queues & Topics in EventBus
	}
	
	@Autowired
	private RestTemplate restTemplate;
	
	private String testPubSub() {
		//create a request Queue & response Queue[load from prop file/config server]
		try {
		Subscription reqQSub = new Subscription("reqQSubscription","http://localhost:9000/order-orchestrator/order-data");
		Subscription respQSub = new Subscription("respQSubscription","http://localhost:9000/order-serv/receive-order");
		QueueData orderReqQ = new QueueData("orderReqQ","westzone.AbcOrg.orderReqQ",true,reqQSub); 
		QueueData orderRespQ = new QueueData("orderRespQ","westzone.AbcOrg.orderRespQ",true,respQSub); 
		ResponseEntity<?> resp =  restTemplate.postForEntity("http://localhost:9000/eventbus/admin/registerQueue",orderReqQ,  String.class);
		System.out.println("request Q created: "+(String) resp.getBody());
		ResponseEntity<?> resp1 =  restTemplate.postForEntity("http://localhost:9000/eventbus/admin/registerQueue",orderRespQ,  String.class);
		System.out.println("response Q created: "+(String) resp1.getBody());
		}catch (Exception e) {
			log.error(e.getMessage());//ignore error
		}
		return  "registrationDone";
	}
	
	
	
	@GetMapping("/test-add-product") 
	public String addProduct(){
		OrderRequestDTO orderDt = new OrderRequestDTO("1000A","ToothPaste","ramaLala",10);
		ResponseEntity<?> resp =  restTemplate.postForEntity("http://localhost:8083/order-serv/order/create",orderDt, String.class);
		String orderCorrelationId =  (String) resp.getBody();
		//pull response with correlatioId (with retry)
		ResponseEntity<PurchaseOrder> result =  restTemplate.getForEntity("http://localhost:8083/order-serv/order/pull-order?responseQ=westzone.AbcOrg.orderRespQ&correlationId="+orderCorrelationId, PurchaseOrder.class);
		return result.toString();
	}
	
}
