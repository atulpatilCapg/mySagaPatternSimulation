package com.mybus.service.order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mybus.exception.MyAppException;
import com.mybus.exception.OperationInProgressException;

@RestController
@RequestMapping("order")
public class OrderController {
	@Autowired
	private IOrderService service;

	// 2 api create order & get orderData
	@PostMapping("/create")
	public String createOrder(@RequestBody OrderRequestDTO order) {
		return this.service.createOrder(order);
	}
	
	@GetMapping("/pull-order") 
	public PurchaseOrder pullOrder(@RequestParam String responseQ,@RequestParam String correlationId) throws MyAppException  {
		try {
			return this.service.pullOrder(responseQ, correlationId);
		} catch (OperationInProgressException e) {
			throw new MyAppException(e.getMessage());
		}
	}

}
