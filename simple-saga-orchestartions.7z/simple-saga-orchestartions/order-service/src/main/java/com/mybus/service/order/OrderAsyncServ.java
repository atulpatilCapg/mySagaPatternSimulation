package com.mybus.service.order;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mybus.common.EventSenderReceiver;
import com.mybus.event.EventMessage;
import com.mybus.exception.OperationInProgressException;

@Service
public class OrderAsyncServ {
	@Autowired
	private EventSenderReceiver senderReceiverApi;
	private ObjectMapper mapper = new ObjectMapper();
	 
	public PurchaseOrder pullResponse(String responseQ, String correlationId) throws OperationInProgressException {
		PurchaseOrder orderResult = null;
		EventMessage eventMsgResp = (EventMessage) senderReceiverApi.pollFromQueue(responseQ, correlationId);
		if(eventMsgResp!= null)
			senderReceiverApi.deleteMsgOnQ(responseQ, correlationId);
		else
			throw new OperationInProgressException("for event:"+correlationId);
		
		System.out.println("@@@@Resuest messageId correlationId=" + correlationId);
		
		if (eventMsgResp != null) {
			System.out.println("@@@@Response correlationId=" + eventMsgResp.getCorrelationID());
			String orderJsonDt = eventMsgResp.getJsonEventData();
			try {
				orderResult = mapper.readValue(orderJsonDt, PurchaseOrder.class);
			} catch (JsonProcessingException e) {
				throw new RuntimeException("Invalid Response:"+e.getMessage());
			}
		}
		return  orderResult ;
	}
}
