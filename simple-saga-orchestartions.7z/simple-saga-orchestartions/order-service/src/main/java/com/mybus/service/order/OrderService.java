package com.mybus.service.order;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mybus.common.EventSenderReceiver;
import com.mybus.event.EventMessage;
import com.mybus.exception.OperationInProgressException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrderService implements IOrderService{
	@Autowired
	private EventSenderReceiver senderReceiverApi;
	@Autowired
	private OrderAsyncServ orderAsyncServ;
	
	private ObjectMapper mapper = new ObjectMapper();
	

@Override
	public String createOrder(OrderRequestDTO order) {
		Map<String,String> eventBusProps= new HashMap<>();
		String msgId = UUID.randomUUID().toString();
		eventBusProps.put("eventName", "createOrder");
		eventBusProps.put("appApiKey","100AAP");//from the api portal registration
		eventBusProps.put("appName","order-service");
		eventBusProps.put("messageGroupId","ERP_01");
		eventBusProps.put("messageID",msgId);
		eventBusProps.put("targetQueue", "westzone.AbcOrg.orderReqQ");
		eventBusProps.put("replyToQueue","westzone.AbcOrg.orderRespQ");
		eventBusProps.put("sequenceNum","0");
		eventBusProps.put("timeStamp",Instant.now().getNano()+"");
		eventBusProps.put("userId","ramaLala");//from session/profile
		try {		
			String jsonMsg = mapper.writeValueAsString(order);
			EventMessage eventInMsg = EventMessage.builder().eventName(eventBusProps.get("eventName"))
					.jsonEventData(jsonMsg).applId(eventBusProps.get("appApiKey"))
					.appName(eventBusProps.get("appName"))
					.messageGroupId(eventBusProps.get("messageGroupId"))
					.messageID(eventBusProps.get("messageID"))
					.targetQueue(eventBusProps.get("targetQueue"))
					.replyToQueue(eventBusProps.get("replyToQueue"))
					.sequenceNum(eventBusProps.get("sequenceNum")).timeStamp(Long.parseLong(eventBusProps.get("timeStamp")))
					.userId(eventBusProps.get("userId")).build();
			
			String result = senderReceiverApi.sendToQueue(eventInMsg.getTargetQueue(), eventInMsg);
			if(result!=null)
			  return eventInMsg.getMessageID();
			else
			  throw new RuntimeException("Event: "+eventInMsg.getMessageID()+"failed to send message to Request Queue");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}
	
     
	@Override
	@Retryable(value = { OperationInProgressException.class }, maxAttempts = 5, backoff = @Backoff(delay = 4000))
	public PurchaseOrder pullOrder(String responseQ, String correlationId) throws OperationInProgressException {
		PurchaseOrder porder = orderAsyncServ.pullResponse(responseQ, correlationId);
		return porder;
	}

	

}
