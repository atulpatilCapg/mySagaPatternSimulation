package com.mybus.service.order;

import com.mybus.exception.OperationInProgressException;

public interface IOrderService {

	String createOrder(OrderRequestDTO order);

	PurchaseOrder pullOrder(String responseQ, String correlationId) throws OperationInProgressException;

}
