package com.mybus.test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mybus.service.inventory.InventoryRespDTO;
import com.mybus.service.payment.PaymentResponseDTO;
import com.mybus.test.ideompotent.ApiIdempotent;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class TestService {
	
 @Autowired
 private ExternalWServ extServ;
 	
	public String testAsyncRestCall() {
		log.info("1:in TestService:testAsync");
		CompletableFuture<PaymentResponseDTO>   resPymt = extServ.callToPaymtService();
		log.info("2:in TestService:called pymt service");
		try {
			PaymentResponseDTO respPymt = resPymt.get();
			log.info(""+respPymt);
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage());
		}
		
		return "testedDone";
	}
	
	public PaymentResponseDTO testAsyncRestCallWithException() {
		CompletableFuture<PaymentResponseDTO>   resPymt = extServ.callToPaymtServiceExp();
		CompletableFuture<PaymentResponseDTO>  newResp = resPymt.exceptionally(e -> {  System.out.println(e.getMessage()); return new PaymentResponseDTO("10A","TestFallback",10); });
		
		try{
			PaymentResponseDTO res = newResp.get();
			System.out.println(res);
			return res;
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage());throw new RuntimeException(e.getMessage());
		}
		 
	}
	

	public String testParallelCall() {
		log.info("1:in TestService:testAsync");
		CompletableFuture<PaymentResponseDTO>   resPymt = extServ.callToPaymtService();
		CompletableFuture<InventoryRespDTO>   resInvt = extServ.callToInventoryService();
		CompletableFuture.allOf(resPymt,resInvt).join();
		log.info("2:in TestService:called both service");
		try {
			PaymentResponseDTO respPymt = resPymt.get();
			InventoryRespDTO respInv = resInvt.get();
			log.info("pymt:"+respPymt);log.info("inv:"+respInv);
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage());
		}
		
		return "testedDone";
	}
	
	public String testParallelCallExpResults() {
		//one of WS fails or both can fails
		//CompletableFuture<PaymentResponseDTO>   resPymt = extServ.callToPaymtService();//WS1:ok 
		CompletableFuture<PaymentResponseDTO>   resPymt = extServ.callToPaymtServiceExp();//WS1:Error ,rest WS call throw error /fails
		//CompletableFuture<InventoryRespDTO>   resInvt = extServ.callToInventoryService();//WS2:ok
		CompletableFuture<InventoryRespDTO>   resInvt = extServ.callToInventoryServiceExp();//WS2: with error
		//parallel call to WS1:payments , and WS2:Inventory
		CompletableFuture.allOf(resPymt,resInvt).exceptionallyAsync((ex)->{
			 //Rollback calls only for succeed WS
			System.out.println("got error in one of Rest WSCall"+ex.getMessage());
			if(!resPymt.isCompletedExceptionally())
		      System.out.println("Triggering Rollback WS calls to Payment Ws:callToPaymtService_Rollback() "); //rollback call to success WS1
			if(!resInvt.isCompletedExceptionally())
			  System.out.println("Triggering Rollback WS calls to Inventory Ws callToInventoryService_Rollback() "); //rollback call to success WS1
		
			return null; })
		.join();
		 
		try {
			boolean allSuccess = true;
			if(resPymt.isCompletedExceptionally() || resInvt.isCompletedExceptionally()) {
				allSuccess = false;
			}
			if(allSuccess) {
				PaymentResponseDTO respPymt = resPymt.get();
				InventoryRespDTO respInv = resInvt.get();
				log.info("pymt:"+respPymt);
				log.info("inv:"+respInv);
			}
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage());
		}
		
		return "testedDone";
	}
	
	
	public PaymentResponseDTO testAsyncWithExceptionWhenComplete() {
		PaymentResponseDTO response = null;
		CompletableFuture<PaymentResponseDTO> resPymt = extServ.callToPaymtServiceExp();//rest call will throw exception
		// CompletableFuture.whenComplete(BiConsumer<Res, Ex>)
		CompletableFuture<PaymentResponseDTO> result = resPymt.whenComplete((res,ex)->{
			if (ex != null) {
				System.err.println("Exception occured in Payment WS call");
			} else {
				System.out.println("Got result from Payment WS call "+res);
		
			}
		});
		try {
			response =  result.join();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	return response;
	}
	
	public PaymentResponseDTO testAsyncWithExceptionHandle() throws Exception {
		CompletableFuture<PaymentResponseDTO> resPymt = extServ.callToPaymtServiceExp();//rest call will throw exception
		CompletableFuture<PaymentResponseDTO> newRes =  resPymt.handle((res, ex) -> {// test with exception

			if (ex != null) {
				PaymentResponseDTO resNew = new PaymentResponseDTO("TestEx", "FallbackProduct" + "_Exception", 0);
				return resNew;
			} else {
				return res;
			}
		});
		return newRes.get();
	}	
	
}
