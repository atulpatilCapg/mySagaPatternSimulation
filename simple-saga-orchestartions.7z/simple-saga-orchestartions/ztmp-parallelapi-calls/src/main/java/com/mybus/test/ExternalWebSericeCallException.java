package com.mybus.test;

public class ExternalWebSericeCallException extends RuntimeException {
private String errCode;
	public ExternalWebSericeCallException(String message,String errCode) {
		super(message);
		this.errCode = errCode;
	}

}
