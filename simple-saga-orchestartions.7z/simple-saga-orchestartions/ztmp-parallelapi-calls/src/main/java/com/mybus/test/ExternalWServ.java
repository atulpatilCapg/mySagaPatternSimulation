package com.mybus.test;

import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.mybus.service.inventory.InventoryRespDTO;
import com.mybus.service.payment.PaymentResponseDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExternalWServ {

	@Async
	public CompletableFuture<PaymentResponseDTO> callToPaymtService() {
		// call to webservice payment
		log.info("##Start:call to webservice payment");
		PaymentResponseDTO resp = new PaymentResponseDTO("rama10", "ToothPaste", 20);
		try { 			Thread.sleep(20);		} catch (InterruptedException e) {		} // delay
		log.info("##End:call to webservice payment");
		return CompletableFuture.completedFuture(resp);
	}

	@Async
	public CompletableFuture<PaymentResponseDTO> callToPaymtServiceExp() {
		try { 			Thread.sleep(700);		} catch (InterruptedException e) {		} // delay
		throw new ExternalWebSericeCallException("PaymentServException:Test exception","1000900GH");
	}
	
	@Async
	public CompletableFuture<InventoryRespDTO> callToInventoryServiceExp() {
		try { 			Thread.sleep(500);		} catch (InterruptedException e) {		} // delay
		throw new ExternalWebSericeCallException("Inventory Webservice exception","900GH");
	}
	
	@Async
	public CompletableFuture<InventoryRespDTO> callToInventoryService() {
		// call to webservice iventory
		log.info("@@Start:call to webservice inventory");
		InventoryRespDTO resp = new InventoryRespDTO("toothPaste",100);
		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
		} // delay
		log.info("@@End:call to webservice inventory");
		return CompletableFuture.completedFuture(resp);
	}

}
