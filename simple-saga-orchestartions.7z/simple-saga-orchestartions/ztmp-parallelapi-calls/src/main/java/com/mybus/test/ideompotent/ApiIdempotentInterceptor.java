package com.mybus.test.ideompotent;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

public class ApiIdempotentInterceptor implements HandlerInterceptor {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		/*
		System.out.println("in ApiIdempotentInterceptor :");
		  if (!(handler instanceof HandlerMethod)) {
	            return true;
	        }
		  HandlerMethod handlerMethod = (HandlerMethod) handler;
	        java.lang.reflect.Method method = handlerMethod.getMethod();
	        ApiIdempotent methodAnnotation = method.getAnnotation(ApiIdempotent.class);
	        if (methodAnnotation != null) {
	        	System.out.println("ideompotent annotation found");
	        	//to do check the request header for event handle uniqueness
	        }
	        */
		return true;
	}

}
