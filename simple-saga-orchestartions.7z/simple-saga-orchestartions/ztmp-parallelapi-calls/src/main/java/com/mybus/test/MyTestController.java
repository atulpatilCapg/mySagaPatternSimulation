package com.mybus.test;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class MyTestController {
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/mytest")
	public String testIdeompotentFunc() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Idempotency-Key",UUID.randomUUID().toString() );
		HttpEntity<?> entity = new HttpEntity<>(headers);
		ResponseEntity<String> resp = restTemplate.exchange(
				"http://localhost:9999/test/async",HttpMethod.GET, entity, String.class); 
		System.out.println(resp.getBody());
		return resp.getBody();
		
	}
}
