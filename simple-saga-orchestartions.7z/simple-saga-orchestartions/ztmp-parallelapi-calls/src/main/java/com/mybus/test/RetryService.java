package com.mybus.test;

import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.mybus.exception.OperationInProgressException;

@Service
public class RetryService  {

	//@Override
	@Retryable(value = { OperationInProgressException.class }, maxAttempts = 5, backoff = @Backoff(delay = 2000))
	public String testRetry() throws OperationInProgressException {
		System.out.println("##########TestRetry==============");
		throw new OperationInProgressException("in progress");
		//return "test";
	}

}
