package com.mybus.test;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class IdeompotentFuncAspect {
	
	//@Autowired
    //private IdempotentTokenService tokenService;
	
	@Around("@annotation(com.mybus.test.ideompotent.ApiIdempotent)")
	public Object idempotentProcessing(ProceedingJoinPoint joinPoint) throws Throwable {
		//before method
		MethodSignature methodSignature = (MethodSignature) joinPoint.getStaticPart().getSignature();
        Method method = methodSignature.getMethod();
        Parameter[] params = method.getParameters();
        //assume first argument for method(whcih is annotated with '@ApiIdempotent')
        if( params[0].getDeclaredAnnotations()[0].annotationType().getSimpleName().equals("RequestHeader")) {
        	String idmId = (String) joinPoint.getArgs()[0];
        	System.out.println("ideompotentId:"+idmId);
        }
		Object proceed = joinPoint.proceed();
	    // method.getReturnType()
		//process after method on resluts 
		System.out.println("after method ");
		
		
		 return proceed;
	}
}
