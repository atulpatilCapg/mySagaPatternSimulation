package com.mybus.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mybus.exception.OperationInProgressException;
import com.mybus.service.payment.PaymentResponseDTO;
import com.mybus.test.ideompotent.ApiIdempotent;

@RestController
@RequestMapping("test")
public class TestController {
	@Autowired
	private TestService service;
	@Autowired
	private RetryService retryService;

	@ApiIdempotent
	@GetMapping("/async")
	public String testIdeompotentFunc(@RequestHeader("Idempotency-Key") String idempotencyKey) {
		return this.service.testAsyncRestCall();
	}
	
	
	
	@GetMapping("/asyncExp")
	public String testAsyncWithException() { //CompletableFuture.exceptionally(xxx)
		System.out.println("Result+ "+ this.service.testAsyncRestCallWithException());
		return "done";
	}
	
	@GetMapping("/asyncHandle")
	public PaymentResponseDTO testAsyncWithExceptionHandle() { //CompletableFuture.handle(BiFunc(Result,Ex,NewResult))
		PaymentResponseDTO result = null;
		try {
			 result = this.service.testAsyncWithExceptionHandle();
			System.out.println("Result+ "+ result);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return result;
	}
	
	
	
	
	@GetMapping("/parallel")
	public String testParallel() {
		return this.service.testParallelCall();
	}
	@GetMapping("/parallelExp")
	public String testParallelCallExpResults() {
		//2 web service parallel call , one of them fail so trigger rollback ws calls 
		return this.service.testParallelCallExpResults();
	}
	
	@GetMapping("/rest-retry")
	public String testRetry() throws Exception{
		try {
			return this.retryService.testRetry();
		} catch (OperationInProgressException e) {
			throw new Exception(e);
		}
	}
	
	
}