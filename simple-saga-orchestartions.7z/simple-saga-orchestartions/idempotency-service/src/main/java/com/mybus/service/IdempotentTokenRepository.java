package com.mybus.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class IdempotentTokenRepository {
	private Map<String, Long> tokenData = new HashMap<>();// clean the ideompotent token after 24 hours
	private Map<String, String> storedResponse = new HashMap<>();//clean the stored response after 24 hours thr scheduled  batch processing

	public String getStoredResponse(String idempotencyKey) {
		return storedResponse.get(idempotencyKey);
	}

	public void addStoredResponse(String idempotencyKey, String responseJson) {
		this.storedResponse.put(idempotencyKey, responseJson);
	}

	// or store the keys in in-memory DB /Cache
	public void storeToken(String idempotencyKey, int timestamp) {
		tokenData.put(idempotencyKey, Long.valueOf(timestamp));
	}

	public boolean checkIfPresent(String idempotencyKey) {
		return tokenData.containsKey(idempotencyKey);
	}

}
