package com.mybus.service;

import java.io.Serializable;
import java.time.LocalTime;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class IdempotentTokenService {

	@Autowired
	private IdempotentTokenRepository idemRepository;
	
	public String createIdempotentToken() {
		String idempotentTkn = UUID.randomUUID().toString();
		idemRepository.storeToken(idempotentTkn, LocalTime.now().getNano() );
		return idempotentTkn;
	}
	
	public boolean checkTokenPresent(HttpServletRequest request) {
		 String token = request.getHeader("Idempotency-Key");
		 if(StringUtils.isEmpty(token))
			 throw new RuntimeException("Token not found in req header :"+token);
		 
		return checkTokenPresent(token);
	}
	
	public boolean checkTokenPresent(String ideompotentToken) {
		 return idemRepository.checkIfPresent(ideompotentToken);
	}
	
	public String getStoredResponse(String idempotencyKey) {
		return idemRepository.getStoredResponse(idempotencyKey);
	}
	
	public boolean storeResponse(String idempotencyKey, String jsonResponse) {
		 idemRepository.addStoredResponse(idempotencyKey, jsonResponse);
		 return true;
	}
	
}
