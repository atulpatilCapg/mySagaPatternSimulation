package com.mybus.service;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Aspect
@Component
public class IdeompotentFuncAspect {
	
	@Autowired
    private IdempotentTokenService tokenService;
	
	private ObjectMapper mapper = new ObjectMapper();
	
	@Around("@annotation(com.mybus.event.idompotent.ApiIdempotent)")
	public Object idempotentProcessing(ProceedingJoinPoint joinPoint) throws Throwable {
		//before method
		MethodSignature methodSignature = (MethodSignature) joinPoint.getStaticPart().getSignature();
        Method method = methodSignature.getMethod();
        Parameter[] params = method.getParameters();
        //assume first argument for method(whcih is annotated with '@ApiIdempotent')
        if( params[0].getDeclaredAnnotations()[0].annotationType().getSimpleName().equals("RequestHeader")) {
        	String idmId = (String) joinPoint.getArgs()[0];
        	
        	if(tokenService.checkTokenPresent(idmId)) {
        		String jsonResp = tokenService.getStoredResponse(idmId);
        		Serializable resp = (Serializable) mapper.readValue(jsonResp, method.getReturnType());
        		System.out.println("ideompotentId:"+idmId);
        		return resp;
        	}else {
        		Object proceed = joinPoint.proceed();//calling the rest WS
        		String jsonResp = mapper.writeValueAsString(proceed);
        		tokenService.storeResponse(idmId, jsonResp);
        		return proceed;
        	}
        }
		return null;
		
	}
}
