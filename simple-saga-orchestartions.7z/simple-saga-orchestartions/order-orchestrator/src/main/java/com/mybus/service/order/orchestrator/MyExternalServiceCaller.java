package com.mybus.service.order.orchestrator;

import java.io.Serializable;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mybus.event.EventMessage;
import com.mybus.service.IdempotentTokenService;
import com.mybus.service.inventory.InventoryReqDTO;
import com.mybus.service.inventory.InventoryRespDTO;
import com.mybus.service.order.OrderRequestDTO;
import com.mybus.service.payment.PaymentRequestDTO;
import com.mybus.service.payment.PaymentResponseDTO;

@Service
public class MyExternalServiceCaller {

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private IdempotentTokenService idmptServ;

	
	@Async
	CompletableFuture<ResponseEntity<PaymentResponseDTO>> callToPaymentServ(EventMessage msg, OrderRequestDTO req) {
		System.out.println("Call to payment-service  ms event:"+msg.getCorrelationID());
		PaymentRequestDTO paymtReq = new PaymentRequestDTO(msg.getUserId(), req.getProductName(),
				req.getQuantity());
		HttpEntity<?> entity = fillHttpHeadersReq(msg, paymtReq);
	
		ResponseEntity<PaymentResponseDTO> resp = restTemplate.exchange(
				"http://localhost:8088/payment-serv/payment/process",HttpMethod.POST, entity, PaymentResponseDTO.class); 
		return CompletableFuture.completedFuture(resp);
	}

	@Async
	CompletableFuture<ResponseEntity<InventoryRespDTO>> callToInventoryServ(EventMessage msg, OrderRequestDTO req) {
		System.out.println("Call to inventory-service  ms"+msg.getCorrelationID());
		InventoryReqDTO inventory = new InventoryReqDTO(msg.getUserId(), req.getProductName(), req.getQuantity());
		HttpEntity<?> entity = fillHttpHeadersReq(msg, inventory);
		ResponseEntity<InventoryRespDTO> respInv = restTemplate.exchange(
				"http://localhost:8089/inventory-serv/inventory/process", HttpMethod.POST,entity, InventoryRespDTO.class);
		return CompletableFuture.completedFuture(respInv);
	}

	public boolean callToInventoryService_Rollback(EventMessage msg, OrderRequestDTO req) {
		System.out.println("Call to inventory-service  rollback, event:"+msg.getCorrelationID());
		InventoryReqDTO inventory = new InventoryReqDTO(msg.getUserId(), req.getProductName(), req.getQuantity());
		HttpEntity<?> entity = fillHttpHeadersReq(msg, inventory);
		ResponseEntity<Boolean> result = restTemplate.exchange(
				"http://localhost:8089/inventory-serv/inventory/process-rollback", HttpMethod.POST,entity, Boolean.class);
		return result.getBody();
	}

	public boolean callToPaymtService_Rollback(EventMessage msg, OrderRequestDTO req) {
		System.out.println("Call to payment-service  rollback, event:"+msg.getCorrelationID());
		PaymentRequestDTO paymtReq = new PaymentRequestDTO(msg.getUserId(), req.getProductName(),
				req.getQuantity());
		HttpEntity<?> entity = fillHttpHeadersReq(msg, req);
		ResponseEntity<Boolean> result  = restTemplate.exchange(
				"http://localhost:8088/payment-serv/payment/process-rollback", HttpMethod.POST, entity , Boolean.class); 
		return result.getBody();
	}
	
	private HttpEntity<?> fillHttpHeadersReq(EventMessage msg, Serializable req) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("CorrelationID", msg.getCorrelationID());
		headers.set("Idempotency-Key",idmptServ.createIdempotentToken() );
		HttpEntity<?> entity = new HttpEntity<>(req,headers);
		return entity;
	}
}
