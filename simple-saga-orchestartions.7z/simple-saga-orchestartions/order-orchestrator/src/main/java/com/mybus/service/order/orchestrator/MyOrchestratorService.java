package com.mybus.service.order.orchestrator;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mybus.common.EventSenderReceiver;
import com.mybus.event.EventMessage;
import com.mybus.service.inventory.InventoryRespDTO;
import com.mybus.service.order.OrderRequestDTO;
import com.mybus.service.order.PurchaseOrder;
import com.mybus.service.payment.PaymentResponseDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MyOrchestratorService {
	@Autowired
	private MyExternalServiceCaller extServ;
	
	private ObjectMapper mapper = new ObjectMapper();
	

	@Autowired
	private EventSenderReceiver senderReceiverApi;

	@Scheduled(initialDelay = 3000, fixedRate = 5000)
	public void run() {//poll to reqQueue
		String sourceQ = "westzone.AbcOrg.orderReqQ";// load from prop file environment
			Serializable event = senderReceiverApi.pollFromQueue(sourceQ,null);
			
			if (event != null) {
				EventMessage msg = (EventMessage) event;
				processEvent(msg);
			}
		
	}

	private void processEvent(EventMessage msg) {
		log.info("processing event:" + msg.getEventName()+"   eventId:"+msg.getMessageID());
		switch (msg.getEventName()) {
		case "createOrder":
			processCreateOrderEvent(msg);
			break;

		default:
			break;
		}
	}

	private void processCreateOrderEvent(EventMessage msg) {
		String json = msg.getJsonEventData();
		
		//setting correlationId for  response and req to external systems
		if(msg.getCorrelationID()==null)
			msg.setCorrelationID(msg.getMessageID());
		
		OrderRequestDTO req= null;PaymentResponseDTO pmtResp=null;InventoryRespDTO invtResp =null;
		try {
			req = mapper.readValue(json, OrderRequestDTO.class);
		} catch (JsonProcessingException e) {
			log.error(e.getMessage());
		}
		
		CompletableFuture<ResponseEntity<PaymentResponseDTO>>   resPymt =extServ.callToPaymentServ(msg,req);
        CompletableFuture<ResponseEntity<InventoryRespDTO>>   resInvt = extServ.callToInventoryServ(msg,req);
        //parallel call to payment & inventory WS if any error then rollback the success WS 
        final OrderRequestDTO reqPmt=req;
    	CompletableFuture.allOf(resPymt,resInvt).exceptionallyAsync((ex)->{
			
			 //Rollback calls only for succeed WS
			System.out.println("got error in one of Rest WSCall"+ex.getMessage());
			if(!resPymt.isCompletedExceptionally()) {
		      System.out.println("Triggering Rollback WS calls to Payment Ws:callToPaymtService_Rollback() "); //rollback call to success WS1
		      boolean rollbk = extServ.callToPaymtService_Rollback(msg,reqPmt);
		  	  //remove message from queue
			  senderReceiverApi.deleteMsgOnQ(msg.getTargetQueue(), msg.getMessageID());
		      log.info("Rollback success:pymt serv:"+rollbk);
			}
			if(!resInvt.isCompletedExceptionally()) {
			  System.out.println("Triggering Rollback WS calls to Inventory Ws callToInventoryService_Rollback() "); //rollback call to success WS1
			  boolean rollbk = extServ.callToInventoryService_Rollback(msg,reqPmt);
			  //remove message from queue
			  senderReceiverApi.deleteMsgOnQ(msg.getTargetQueue(), msg.getMessageID());
			  log.info("Rollback success:inventory serv:"+rollbk);
			}
			return null; })
		.join();
		try { 
			boolean allSuccess = true;
			if(resPymt.isCompletedExceptionally() || resInvt.isCompletedExceptionally()) {
				allSuccess = false;
			}
			if(allSuccess) {
				//remove message from queue
				senderReceiverApi.deleteMsgOnQ(msg.getTargetQueue(), msg.getMessageID());
				ResponseEntity<PaymentResponseDTO> respPymt = resPymt.get();
				ResponseEntity<InventoryRespDTO> respInv = resInvt.get();
				log.info("pymt:WS resp: code="+respPymt.getStatusCodeValue()+"   details="+respPymt.getBody());
				log.info("inv:WS resp:code="+respInv.getStatusCodeValue()+"  details="+respInv.getBody());
				PurchaseOrder order = new PurchaseOrder();
				order.setOrderId(req.getOrderId());order.setProductName(req.getProductName());
				order.setUserId(req.getUserId());order.setOrderedQuantity(req.getQuantity());
				order.setAmountPaid(respPymt.getBody().getAmountDeducted());
				publishOrderOnResponseQ(order,msg);
			}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage());
		}
	}

	private boolean  publishOrderOnResponseQ(PurchaseOrder order, EventMessage inputMsg) {
		try {
		String jsonMsg = mapper.writeValueAsString(order);
		String msgId = UUID.randomUUID().toString();//response has unique msg id ( but same coorelatioId as of request)
		
		EventMessage eventRespMsg = EventMessage.builder().eventName("purchaseOrder")
				.jsonEventData(jsonMsg).applId(inputMsg.getApplId())
				.appName(inputMsg.getAppName())
				.correlationID(inputMsg.getCorrelationID()) //same as request
				.messageGroupId(inputMsg.getMessageGroupId())
				.messageID(msgId) 
				.replyToQueue(inputMsg.getReplyToQueue())
				.timeStamp(Long.valueOf(  Instant.now().getNano()))
				.userId(inputMsg.getUserId()).build();
		
		 senderReceiverApi.sendToQueue(eventRespMsg.getReplyToQueue(), eventRespMsg);//send event on reply queue
		} catch (Exception e) {
			log.error("Error: "+e.getMessage());
			return false;
		}
		return true;
	}
	
	
}
