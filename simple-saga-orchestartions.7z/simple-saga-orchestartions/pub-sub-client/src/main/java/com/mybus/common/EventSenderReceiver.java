package com.mybus.common;

import java.io.Serializable;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mybus.event.EventMessage;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EventSenderReceiver {
	//wrap the message in EventMessage and send to simple-queue-service of EventBus server
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	public String sendToQueue(String respQueueName, EventMessage eventMsg) {
			ResponseEntity<?> resp =  restTemplate.postForEntity("http://localhost:9000/eventbus/serv/send-to-queue/"+respQueueName, eventMsg, String.class);
			String result = (String) resp.getBody();
			log.info("mesg published to queue: {}", result);
			return result;
	}
	
	
	public Serializable pollFromQueue(String sourceQ,String correlationId) {
		String url = "http://localhost:9000/eventbus/serv/poll-from-queue/"+sourceQ;

		if(correlationId != null)
		 url = url + "?correlationId="+correlationId;
			
		ResponseEntity<EventMessage> resp =  restTemplate.getForEntity(url, EventMessage.class);
		return resp.getBody();
	}
	
	public boolean deleteMsgOnQ(String sourceQ,String messageId) {//delete operation is ideompotent
		restTemplate.delete("http://localhost:9000/eventbus/serv/delete-msg/"+sourceQ+"/"+messageId);
		return true;
	}
	

}
