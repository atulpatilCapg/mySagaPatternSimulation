package com.simple.eventbus;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class SubscriberMethodFinder {
	 private static final Map<Class<?>, List<SubscriberMethod>> METHOD_CACHE = new ConcurrentHashMap<>();
	 

	public List<SubscriberMethod> findSubscriberMethod(Class<?> subscriberCls) {
		List<SubscriberMethod> subscribermths = METHOD_CACHE.get(subscriberCls);
		
		if (subscribermths!=null) {
			return subscribermths;
		}
		if(subscribermths==null) {
			//find methods with @Subscribe  on methods using reflection 
			Method[] methods = subscriberCls.getDeclaredMethods();
			for (Method method : methods) {
				int mod = method.getModifiers();
				if(Modifier.isPublic(mod)) {
					 Subscribe subscribeAnnotation = method.getAnnotation(Subscribe.class);
                    if (subscribeAnnotation != null) {
                    	Class<?>[] params = method.getParameterTypes();
                    	Class<?> eventType = params[0];//event class type
                    	if(subscribermths==null)
                    		subscribermths = new CopyOnWriteArrayList<SubscriberMethod>();
                    	
                    	subscribermths.add(new SubscriberMethod(method, eventType));
                    }
				}
			}
		}
		if(subscribermths!=null)
			METHOD_CACHE.put(subscriberCls, subscribermths);
		
		return subscribermths;
	}

}
