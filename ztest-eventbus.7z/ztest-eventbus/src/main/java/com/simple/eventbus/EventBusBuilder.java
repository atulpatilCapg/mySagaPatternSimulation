package com.simple.eventbus;

import java.util.concurrent.ExecutorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class EventBusBuilder {
	
	@Autowired
	@Qualifier("cachedThreadPool")
	private ExecutorService executorService;
	
	
	public ExecutorService executorService() {
		return executorService;
	}
	
	public EventBus build() {
		return new EventBus(this);
	}

}
