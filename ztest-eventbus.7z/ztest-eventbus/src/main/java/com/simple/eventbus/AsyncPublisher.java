package com.simple.eventbus;

import java.util.concurrent.ConcurrentLinkedQueue;

public class AsyncPublisher implements IPublisher,Runnable{
private final EventBus eventBus;
private final ConcurrentLinkedQueue<PendingPost> queue;


	public AsyncPublisher(EventBus eventBus) {
		this.eventBus=eventBus;
		queue = new ConcurrentLinkedQueue<>();
	}


	@Override
	public void run() {
		PendingPost post = queue.poll();
	    if(post == null) {
            throw new IllegalStateException("No pending post available");
        }
	    eventBus.invokeSubscriber(post);
	}


	public void enqueue(Subscription subscription, Object event) {
		PendingPost postData =  PendingPost.obtainPendingPost(subscription, event);
		queue.add(postData);
		eventBus.getExecutorService().submit(this);//put in thread pool async exec
	}

}
