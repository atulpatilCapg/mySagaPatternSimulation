package com.simple.eventbus.mvc;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Service;

import com.simple.eventbus.EventBus;
import com.simple.eventbus.subscriber.MyOrderScubscriber;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EventBusService {
		private EventBus eventBus;
		
		Map<String,Object> subscribersData = new HashMap<>();	
		
		
		@PostConstruct
		private void init() {
			eventBus = EventBus.getDefault();
			
			loadSubscriberData();
			
		}
		@PreDestroy
		public void cleanup() {
			subscribersData.clear();
			subscribersData=null;
		}
		

		public String registerSubscriber(String subscriberName) {
			eventBus.register(subscribersData.get(subscriberName));
			return "registeredOk";
		}
		
		
		private void loadSubscriberData() {
			try {
				Object orderSubscr=  Class.forName(MyOrderScubscriber.class.getName()).newInstance();
				subscribersData.put("MyOrderScubscriber", orderSubscr);
				
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				log.error(e.getMessage());
			}
		}
		
		public String publishEvent(Object evenObj) {
			return eventBus.publishEvent(evenObj);
		}

}
