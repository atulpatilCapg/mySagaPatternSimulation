package com.simple.eventbus;

import java.util.ArrayList;
import java.util.List;

public class PendingPost {
	Object event;
	Subscription subscription;
	private final static List<PendingPost> pendingPostPool = new ArrayList<>();

	private PendingPost(Object event, Subscription subscription) {
		this.event = event;
		this.subscription = subscription;
	}

	static PendingPost obtainPendingPost(Subscription subscription, Object event) {
		synchronized (pendingPostPool) {
			int size = pendingPostPool.size();
			if (size > 0) {
				PendingPost post = pendingPostPool.remove(pendingPostPool.size()-1);
				post.event=event;
				post.subscription=subscription;
				return post;
			}
		}
		return new PendingPost(event, subscription);
	}
	
	static void releasePendingPost(PendingPost post) {
		post.event=null;post.subscription=null;
		synchronized (pendingPostPool) {
			if (pendingPostPool.size()<10000) {
				pendingPostPool.add(post);
			}
		}
	}
}
