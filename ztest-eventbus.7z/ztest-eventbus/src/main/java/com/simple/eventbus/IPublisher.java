package com.simple.eventbus;

public interface IPublisher {
	public void enqueue(Subscription subscription, Object event);
}
