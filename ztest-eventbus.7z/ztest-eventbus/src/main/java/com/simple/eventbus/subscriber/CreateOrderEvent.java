package com.simple.eventbus.subscriber;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;


@Getter
public class CreateOrderEvent implements Serializable {
	private static final long serialVersionUID = 5705135051269439346L;
	private final String orderId;
	private final int quantity;
	private final String productId;
	
	public CreateOrderEvent( String orderId, int quantity, String productId) {
		this.orderId = orderId;
		this.quantity = quantity;
		this.productId = productId;
	}
	
	
	
	
}
