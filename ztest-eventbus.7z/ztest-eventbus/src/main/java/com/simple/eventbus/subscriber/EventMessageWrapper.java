package com.simple.eventbus.subscriber;

import java.io.Serializable;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Getter;
@AllArgsConstructor
@Getter
public class EventMessageWrapper implements Serializable{
	
	private final String eventId = UUID.randomUUID().toString();//ideompotencyId
	//correlationId
	private final Object eventObj;

}
