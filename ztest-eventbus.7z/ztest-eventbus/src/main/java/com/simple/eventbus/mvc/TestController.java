package com.simple.eventbus.mvc;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.simple.eventbus.subscriber.CreateOrderEvent;
import com.simple.eventbus.subscriber.EventMessageWrapper;
import com.simple.eventbus.subscriber.MyOrderScubscriber;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TestController {

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/test-order")
	public String testOrder() {
		MyOrderScubscriber orderSubscriber1 = new MyOrderScubscriber();
		ResponseEntity<?> resp = restTemplate.postForEntity("http://localhost:8087/event-bus/register-subscriber",
				"MyOrderScubscriber", String.class);
		return resp.getBody().toString();
	}

	@GetMapping("/test-order-publish")
	public String testOrderPublish() {
		CreateOrderEvent order = new CreateOrderEvent("1000A", 10, "Tp500");
		EventMessageWrapper eventWrp = new EventMessageWrapper(order);
		 RequestEntity request;
		try {
			request = RequestEntity
				     .post(new URI("http://localhost:8087/event-bus/publish-event"))
				     .body(eventWrp);
			ResponseEntity<?> resp = restTemplate.exchange(request,	String.class);
			return resp.getBody().toString();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return "test";
		
	}
//	public String testOrderPublish() {
//		CreateOrderEvent order = new CreateOrderEvent("1000A", 10, "Tp500");
//		ResponseEntity<?> resp = restTemplate.postForEntity("http://localhost:8087/event-bus/publish-event", order,
//				String.class);
//		return resp.getBody().toString();
//	}

}
