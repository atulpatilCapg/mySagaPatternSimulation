package com.simple.eventbus;

import java.lang.reflect.Method;
import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
public class SubscriberMethod {
	final Method method;
	final Class<?> eventType;
	String methodString;
	public SubscriberMethod(Method method, Class<?> eventType) {
		this.method = method;
		this.eventType = eventType;
	}
	
	
	@Override
	public int hashCode() {
		return method.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (obj instanceof SubscriberMethod) {
			SubscriberMethod other = (SubscriberMethod) obj;
			if (methodString == null) {
	            // Method.toString has more overhead, just take relevant parts of the method
	            StringBuilder builder = new StringBuilder(64);
	            builder.append(method.getDeclaringClass().getName());
	            builder.append('#').append(method.getName());
	            builder.append('(').append(eventType.getName());
	            methodString = builder.toString();
	        }
			return methodString.equals(((SubscriberMethod) obj).methodString);
		}
		return false;
			
	}

}
