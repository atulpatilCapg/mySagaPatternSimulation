package com.simple.eventbus;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;

import org.springframework.util.ObjectUtils;

import com.simple.eventbus.EventBus.PublisherState;
import com.simple.eventbus.event.SubscriberExceptionEvent;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EventBus {
	static volatile EventBus defaultInstance; // singleton instance
	private final ExecutorService executorService;
	private static final EventBusBuilder DEFAULT_BUILDER = new EventBusBuilder();

	private final Map<Class<?>, CopyOnWriteArrayList<Subscription>> subscriptionsByEventType;
	private final Map<Object, List<Class<?>>> typesBySubscriber;

	private final SubscriberMethodFinder subscriberMethodFinder;

	private final AsyncPublisher asyncPoster;

	// thread local state storage
	private final ThreadLocal<PublisherState> publiherStateHolder = new ThreadLocal<PublisherState>() {
		@Override
		protected PublisherState initialValue() {
			return new PublisherState();
		}
	};

	// static final class holds state
	final static class PublisherState {
		final List<Object> eventQueue = new ArrayList<>();
		boolean isPosting;
		Subscription subscription;
		Object event;
		boolean canceled;
	}

	public static EventBus getDefault() {
		EventBus instance = defaultInstance;
		if (instance == null) {
			synchronized (EventBus.class) {
				instance = EventBus.defaultInstance;
				if (instance == null) {
					instance = EventBus.defaultInstance = new EventBus();
				}
			}
		}
		return instance;
	}

	public EventBus() {
		this(DEFAULT_BUILDER);
	}

	public EventBus(EventBusBuilder defaultBuilder) {
		subscriptionsByEventType = new HashMap<>();
		typesBySubscriber = new HashMap<>();
		executorService = defaultBuilder.executorService();
		subscriberMethodFinder = new SubscriberMethodFinder();
		asyncPoster = new AsyncPublisher(this);
	}

	public ExecutorService getExecutorService() {
		return executorService;
	}

	// Registers the given subscriber to receive events.
	// Subscribers have event handling methods that must be annotated by {@link
	// Subscribe}.
	public void register(Object subscriber) {
		Class<?> subscriberCls = subscriber.getClass();
		List<SubscriberMethod> methods = subscriberMethodFinder.findSubscriberMethod(subscriberCls);
		synchronized (this) {
			for (SubscriberMethod subscriberMethod : methods) {
				subscribe(subscriber, subscriberMethod);
			}
		}
	}

	private void subscribe(Object subscriber, SubscriberMethod subscriberMethod) {
		Class<?> eventType = subscriberMethod.eventType;
		Subscription newSub = new Subscription(subscriber, subscriberMethod);
		CopyOnWriteArrayList<Subscription> subscriptions = subscriptionsByEventType.get(eventType);
		if (subscriptions == null) {
			subscriptions = new CopyOnWriteArrayList<>();
			subscriptionsByEventType.put(eventType, subscriptions);
		}else {
			if(subscriptions.contains(newSub))
				throw new RuntimeException("Subscriber " + subscriber.getClass() + " already registered to event "
                        + eventType);
		}
		
		if(!subscriptions.contains(newSub))
			subscriptions.add(newSub);

		List<Class<?>> subscribedEvents = typesBySubscriber.get(subscriber);
		if (subscribedEvents == null) {
			subscribedEvents = new ArrayList<>();
			typesBySubscriber.put(subscriber, subscribedEvents);
		}

		subscribedEvents.add(eventType);
	}

	public synchronized boolean isRegistered(Object subscriber) {
		return typesBySubscriber.containsKey(subscriber);
	}

	public synchronized void unregister(Object subscriber) {
		List<Class<?>> subscribedTypes = typesBySubscriber.get(subscriber);
		if (subscribedTypes != null) {
			for (Class<?> eventType : subscribedTypes) {
				List<Subscription> subscriptions = subscriptionsByEventType.get(eventType);
				if (subscriptions != null) {
					int size = subscriptions.size();
					for (int i = 0; i < size; i++) {
						Subscription subscription = subscriptions.get(i);
						if (subscription.subscriber == subscriber) {
							// subscription.active = false;
							subscriptions.remove(i);
							i--;
							size--;
						}
					}
				}
			}
			typesBySubscriber.remove(subscriber);
		} else {
			System.err.println("subscriber is not registered earlier" + subscriber);
		}
	}

	// post/publish event to event bus
	public String publishEvent(Object event) {
		PublisherState publishState = publiherStateHolder.get();
		List<Object> queue = publishState.eventQueue;
		queue.add(queue);
		if (!publishState.isPosting) {
			publishState.isPosting = true;

			if (publishState.canceled) {
				throw new RuntimeException("Internal error. Abort state was not reset");
			}
			try {
				while (!queue.isEmpty()) {
					publishSingleEvent(queue.remove(0), publishState);
				}
			} finally {
				publishState.isPosting = false;
			}
		}
		return "eventpublished";

	}

	private void publishSingleEvent(Object event, PublisherState publishState) {
		Class<?> evetCls = event.getClass();

		CopyOnWriteArrayList<Subscription> subscriptions;
		synchronized (this) {
			subscriptions = subscriptionsByEventType.get(evetCls);
		}

		if (!ObjectUtils.isEmpty(subscriptions)) {
			for (Subscription subscription : subscriptions) {
				publishState.event = event;
				publishState.subscription = subscription;
				try {
					asyncPoster.enqueue(subscription, event);
				} finally {
					publishState.event = null;
					publishState.subscription = null;
				}

			}
		}

	}

	public void invokeSubscriber(PendingPost post) {
		Object event = post.event;
		Subscription subscription = post.subscription;
		PendingPost.releasePendingPost(post);
		try {
			subscription.subscriberMethod.method.invoke(subscription.subscriber, event);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// handle exception Based on flags or throw it
			// throw new RuntimeException("Invoking subscriber failed", e);

			log.error(e.getMessage());
			// send error to bus queue
			post(new SubscriberExceptionEvent(this, e));
		}

	}

	public void post(Object event) {
		PublisherState state = publiherStateHolder.get();
		List<Object> eventQueue = state.eventQueue;
		eventQueue.add(event);
		if (!state.isPosting) {
			state.isPosting = true;
			if (state.canceled) {
				throw new RuntimeException("Internal error. Abort state was not reset");
			}
			try {
				while (!eventQueue.isEmpty()) {
					Class<?> eventCls = event.getClass();

					CopyOnWriteArrayList<Subscription> subscriptions;
					synchronized (this) {
						subscriptions = subscriptionsByEventType.get(eventCls);
					}

					for (Subscription subscription : subscriptions) {
						asyncPoster.enqueue(subscription, event);
					}

				}
			} finally {
				state.isPosting = false;
			}

		}

	}

}
