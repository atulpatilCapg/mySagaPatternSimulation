package com.simple.eventbus.subscriber;

import com.simple.eventbus.Subscribe;
public class MyOrderScubscriber {

	//event handler methods 
	@Subscribe
	public void onCreateOrderEvent(CreateOrderEvent event) {
		System.out.println("#####In onCreateOrderEvent: got event: " + event);
		System.out.println("in create order event handler");
	}
	
	
	
	
}
