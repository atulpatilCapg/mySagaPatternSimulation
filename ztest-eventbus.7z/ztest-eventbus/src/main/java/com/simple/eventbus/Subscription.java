package com.simple.eventbus;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Subscription {
	final Object subscriber;
	final SubscriberMethod subscriberMethod;

	@Override
	public int hashCode() {
		return subscriber.hashCode() + subscriberMethod.hashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other instanceof Subscription) {
			Subscription otherSubscription = (Subscription) other;
			return subscriber == otherSubscription.subscriber
					&& subscriberMethod.equals(otherSubscription.subscriberMethod);
		} else {
			return false;
		}
	}

}
