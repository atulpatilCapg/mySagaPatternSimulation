package com.simple.eventbus.event;

import com.simple.eventbus.EventBus;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public final class SubscriberExceptionEvent {
//immutable cls
	public final EventBus eventBus;
	public final Throwable throwable;
}
