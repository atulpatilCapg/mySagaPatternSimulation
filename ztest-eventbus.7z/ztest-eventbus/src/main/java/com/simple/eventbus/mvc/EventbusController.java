package com.simple.eventbus.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.simple.eventbus.subscriber.EventMessageWrapper;


@RestController
public class EventbusController {
	
	@Autowired
	private EventBusService service;

	// 2 api create order & get orderData
	@PostMapping("/register-subscriber")
	public String registerSubscriber(@RequestBody String subscriberName) {
		return this.service.registerSubscriber(subscriberName);
	}
	
	@PostMapping(value="/publish-event")
	public String publishEvent(@RequestBody EventMessageWrapper evenWrp) {
		return this.service.publishEvent(evenWrp.getEventObj());
	}
	
//	@GetMapping("/pull-order") 
//	public PurchaseOrder pullOrder(@RequestParam String responseQ,@RequestParam String correlationId) throws MyAppException  {
//		try {
//			return this.service.pullOrder(responseQ, correlationId);
//		} catch (OperationInProgressException e) {
//			throw new MyAppException(e.getMessage());
//		}
//	}

}
