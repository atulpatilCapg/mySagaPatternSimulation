package com.simple.eventbus;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;
@Configuration
@SpringBootApplication
public class MyEventBusApp {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(MyEventBusApp.class, args);
    }
    
    @Bean("cachedThreadPool")
    public ExecutorService cachedThreadPoolExec() {
    	return Executors.newCachedThreadPool();
	}
    
    
    @Bean
   	public RestTemplate restTemplate(RestTemplateBuilder builder) {
   		return builder.build();
   	}
       
      @Bean
	public Executor executor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(3);
		executor.setMaxPoolSize(3);
		executor.setQueueCapacity(500);
		executor.initialize();
		return executor;
	}
}
